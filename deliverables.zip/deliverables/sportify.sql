-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2015 at 01:28 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sportify`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `description`, `version`) VALUES
('6eb35fa5-5309-42e1-ab7d-1a779f537707', 'Winter Sports', 'all Winter Sport.', 1),
('9ae340bf-8662-4b0a-af2f-ce5f3bcbe0b2', 'Ball Sport', 'All ball Sports', 1),
('b01816f4-a97a-4ed1-a96e-8b179eff3797', 'Water Sport', 'All water sports.', 1),
('ffc9f1ae-d20c-4096-9f02-31e7b156e4d9', 'Gymnastic', 'Gymnastic and Dance', 1);

-- --------------------------------------------------------

--
-- Table structure for table `externalteam`
--

CREATE TABLE IF NOT EXISTS `externalteam` (
  `team_id` varchar(36) NOT NULL,
  `version` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `externalteam`
--

INSERT INTO `externalteam` (`team_id`, `version`) VALUES
('77b6d3d6-5669-4790-b7c6-7c56e960b085', 0),
('7a277487-2bce-42f6-8ac2-86ee92f9c20c', 0),
('9fd74103-ecf4-4924-b861-0f4efa441fee', 0),
('a862648b-a772-4a8a-9c9e-af671eb018f6', 0),
('e92ba06a-8d2f-11e5-8994-feff819cdc9f', 0),
('e92ba376-8d2f-11e5-8994-feff819cdc9f', 0);

-- --------------------------------------------------------

--
-- Table structure for table `internalteam`
--

CREATE TABLE IF NOT EXISTS `internalteam` (
  `team_id` varchar(36) NOT NULL,
  `trainer_id` varchar(36) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `internalteam`
--

INSERT INTO `internalteam` (`team_id`, `trainer_id`, `version`) VALUES
('0a6c1426-a382-4a1c-a27a-cc40e75e03aa', '57322168-3e82-4bf4-9d64-c23a1e00bf51', 0),
('10b36dc7-c8a1-44bb-96c3-ab90a2920386', '72ea88dd-2962-462d-bc55-9b14a80d4d52', 0),
('300783e6-c4da-4a3b-b3c8-063f307b6e2d', 'e8f036f9-6f99-4a7f-8411-2c62063539f2', 0),
('575135ae-86d4-407c-ba24-067307c608ba', '7f86baa0-a6c7-42bd-9870-3697ae2fa1f6', 0),
('5e6cfb5d-696d-474a-9787-fe473cb11000', '68a4dbb2-d644-461f-b1e3-8021d0e44464', 0),
('64738de2-c246-4862-aaaf-58f20dc15a0a', '57322168-3e82-4bf4-9d64-c23a1e00bf51', 0),
('7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1', '6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', 0),
('9bb34421-ed31-4d4c-891f-113f0c728263', '604a80ca-4610-4155-88a2-ec7e4b40e9ca', 0),
('9fd4ada9-29b5-40d5-a292-686096db5e51', '604a80ca-4610-4155-88a2-ec7e4b40e9ca', 0);

-- --------------------------------------------------------

--
-- Table structure for table `match_`
--

CREATE TABLE IF NOT EXISTS `match_` (
  `id` varchar(36) NOT NULL,
  `duration` int(11) DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `tournament_id` varchar(36) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `match_`
--

INSERT INTO `match_` (`id`, `duration`, `start`, `tournament_id`, `version`, `status`) VALUES
('09a90e45-156e-4078-8bb2-0d103b90da34', 124, '2015-11-17 18:33:31', 'efaebdd1-8fae-4d6c-9c59-9a08807e0b71', 1, NULL),
('0a6c1426-a382-4a1c-a27a-cc40e75e03aa', 200, '2015-11-17 18:35:13', 'efaebdd1-8fae-4d6c-9c59-9a08807e0b71', 1, NULL),
('48ce1cd7-c94c-4579-8adb-34c3cfbd8634', 5, '2015-12-25 00:00:00', '3252d203-65de-48b3-afe9-5d641afe7002', 1, 'PLANNED'),
('5796b679-5852-4f70-9898-094b7382ed60', 79, '3914-03-10 00:00:00', '9234c857-f77b-4f56-8d48-1e007313b128', 1, 'PLANNED'),
('5df2c6bf-0329-46f1-acaa-468f4ca2899c', 90, '2015-12-17 00:00:00', 'e41cfa4b-3cf1-4ea0-bdb4-d77897fad070', 1, 'PLANNED'),
('61a245ce-ba40-43bc-bfff-9830469bd6f4', 25, '2015-11-28 00:00:00', 'da5e56ed-f908-4f7c-b682-2fed72db4549', 1, 'PLANNED'),
('862e2813-6965-4f49-9bdb-3921c3df197d', 20, '3914-03-10 00:00:00', '7c9daf6c-0785-4cfd-b7a7-27ef4f79b3ad', 1, 'PLANNED'),
('8db895f9-cae0-43b2-9034-85801c141656', 90, '2015-12-01 00:00:00', '5d5c2c90-45a1-4e57-8d45-3cea71f7a134', 1, 'PLANNED'),
('db019757-aa73-42ad-9d58-897f900e9015', 90, '2015-12-15 00:00:00', '09d50e2e-0d36-4b71-9589-d317b690681b', 1, 'PLANNED'),
('fdc01451-9241-4090-8b2a-7dc848570685', 5, '2015-12-30 00:00:00', '95ffa7a7-a0ae-4c00-babc-af8599520e9b', 1, 'PLANNED');

-- --------------------------------------------------------

--
-- Table structure for table `match_team`
--

CREATE TABLE IF NOT EXISTS `match_team` (
  `id` varchar(36) NOT NULL,
  `match_id` varchar(36) NOT NULL,
  `team_id` varchar(36) NOT NULL,
  `roster_id` varchar(36) DEFAULT NULL,
  `points` varchar(255) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `id` varchar(36) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `housenumber` varchar(255) DEFAULT NULL,
  `postalcode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `birthdate` varchar(255) DEFAULT NULL,
  `paid` int(11) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id`, `firstname`, `lastname`, `street`, `housenumber`, `postalcode`, `city`, `email`, `birthdate`, `paid`, `version`, `username`) VALUES
('0d26e707-6a20-47cf-bb1b-f65c5edfb0c1', 'Monika', 'Schneider', '', '', '', '', '', '22.08.1991', 1, 0, NULL),
('0d7eeba8-bcac-4af8-a2bf-a4f159e85cf5', 'Hans', 'Wohlgemut', '', '', '', '', 'hans.wohlgemut@froehlich.at', '18.02.1960', 1, 0, NULL),
('231cd6ed-f033-499e-abb8-abaa60826d1f', 'Bonnie', 'Reyes', 'Banding', '7', '6961', 'Boli', 'breyes5@godaddy.com', '9/26/1990', 1, 12, 'tf-test'),
('3799b4a6-c637-4f47-9a88-219f09beddee', 'Lois', 'Moore', 'Crowley', '6', '6961', 'Mlawat', 'lmoore0@jiathis.com', '11/6/1983', 0, 10, NULL),
('37ef7152-4187-45bb-a4a1-5126e3f4d1c7', 'Niklas', 'Fessler', 'Irisweg', '14', '6971', 'Hard', 'niklas.fessler@gmail.com', '28.03.1991', 1, 1, 'nfe3303'),
('3e6dde97-ee20-4a0c-b12d-6e2aa150dbc3', 'John', 'Garcia', 'Vista Chino', '666', '92241', 'Sky Valley', 'john.garcia@skyvalley.com', '04.09.1970', 1, 1, NULL),
('41f04f60-c399-42fb-9331-03aac7694fc2', 'Simon', 'Hartmann', 'Flachsweg', '1', '6835', 'Muntlix', 'simon1hartmann@gmail.com', '11.12.1991', 1, 2, 'sha9939'),
('57322168-3e82-4bf4-9d64-c23a1e00bf51', 'Theresa', 'Hall', 'Artisan', '5197', '6924', 'Mariefred', 'thall2@issuu.com', '3/5/1983', 1, 10, NULL),
('5ed81ec1-a9b5-4c1e-a6b7-0ae11395f4a4', 'Caroline', 'Meusburger', 'Emme ', '6d', '6844', 'Altach', 'caro.meusburger@vol.at', '22.07.1994', 1, 0, 'cme8625'),
('604a80ca-4610-4155-88a2-ec7e4b40e9ca', 'Wayne', 'Hansen', 'Sage', '01', '6925', 'Sukorambi', 'whansen6@hatena.ne.jp', '7/24/1989', 0, 1, NULL),
('68a4dbb2-d644-461f-b1e3-8021d0e44464', 'Heinz', 'Gabriel', '', '', '', '', '', '01.01.1950', 1, 7, NULL),
('6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', 'Barbara', 'Spencer', 'Shelley', '0975', '6928', 'Luohuang', 'bspencer3@salon.com', '5/31/1992', 1, 2, NULL),
('71cfa130-ed9c-4b91-bacd-dfdfb58ed572', 'Nicole', 'Walker', 'Clarendon', '98073', '6981', 'Injīl', 'nwalker1@miitbeian.gov.cn', '3/28/1987', 0, 1, NULL),
('72ea88dd-2962-462d-bc55-9b14a80d4d52', 'Tom', 'Turbo', '', '', '', '', 'tom.turbo@gmail.com', '01.01.2000', 1, 5, NULL),
('73e45ce3-5ce6-48d9-9384-03a4a92a9733', 'Tom', 'Jones', '', '', '', '', '', '01.01.1990', 1, 0, NULL),
('7f86baa0-a6c7-42bd-9870-3697ae2fa1f6', 'Peter', 'Maffai', '', '', '', '', '', '01.01.1950', 1, 0, NULL),
('89b57ed7-ec02-44f9-947c-75aceae661bb', 'Charly', 'Brown', '', '', '', '', '', '01.01.1999', 1, 0, NULL),
('93550bad-9d9b-4502-852f-972769e492f6', 'Michael', 'Troy', '', '', '', '', '', '25-03.1993', 1, 0, 'mtr6934'),
('9d1275c5-b4b5-468a-bf21-63922139f334', 'Mildred', 'Smith', 'Independence', '8753', '6951', 'Abengourou', 'msmith8@cbc.ca', '3/1/1993', 0, 1, NULL),
('cf0fc9f5-0e72-406e-b365-b69e52e335d8', 'Patrick', 'Schedler', 'Hof', '1104', '6861', 'Alberschwende', 'patrick_schedler@hotmail.com', '17.09.1989', 1, 0, 'psc6365'),
('e5e78e5e-7e1f-4f4f-b85b-a460d45b966d', 'John', 'McLovin', '', '', '', '', '', '12.02.1988', 1, 1, NULL),
('e8f036f9-6f99-4a7f-8411-2c62063539f2', 'Nicole', 'Welch', 'Declaration', '3145', '6951', 'Belköl', 'nwelch7@dropbox.com', '3/7/1990', 1, 8, NULL),
('f284b9d7-7a42-43f3-a838-1dffa89ac17c', 'John', 'Hayes', 'Toban', '99448', '6949', 'Oslo', 'jhayes4@comcast.net', '6/12/1990', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `person_sport`
--

CREATE TABLE IF NOT EXISTS `person_sport` (
  `person_id` varchar(36) NOT NULL,
  `sport_id` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `person_sport`
--

INSERT INTO `person_sport` (`person_id`, `sport_id`) VALUES
('3e6dde97-ee20-4a0c-b12d-6e2aa150dbc3', '574b4b92-f95f-4021-8b14-1f63e3f100cc'),
('0d26e707-6a20-47cf-bb1b-f65c5edfb0c1', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f'),
('37ef7152-4187-45bb-a4a1-5126e3f4d1c7', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f'),
('41f04f60-c399-42fb-9331-03aac7694fc2', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f'),
('0d26e707-6a20-47cf-bb1b-f65c5edfb0c1', 'e92b920a-8d2f-11e5-8994-feff819cdc9f'),
('41f04f60-c399-42fb-9331-03aac7694fc2', 'e92b920a-8d2f-11e5-8994-feff819cdc9f'),
('37ef7152-4187-45bb-a4a1-5126e3f4d1c7', 'e92b9cfa-8d2f-11e5-8994-feff819cdc9f'),
('3e6dde97-ee20-4a0c-b12d-6e2aa150dbc3', 'ea252d67-9e8e-444f-908b-3800eeb8e06b'),
('41f04f60-c399-42fb-9331-03aac7694fc2', 'ea252d67-9e8e-444f-908b-3800eeb8e06b');

-- --------------------------------------------------------

--
-- Table structure for table `roster`
--

CREATE TABLE IF NOT EXISTS `roster` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roster`
--

INSERT INTO `roster` (`id`, `name`, `version`) VALUES
('34c159e9-faed-42dd-aa80-9acf6b19d818', 'ALIEN INVADERS', 1),
('72711c97-237c-49af-a0e0-452fb01295a7', 'ALIEN PANTHERS ALIENS', 1),
('8c992261-d4cc-4867-aec2-38d000292a43', 'ACOLYTES', 1),
('a0b1adb8-e417-41c5-b073-e5695656b14a', 'AGUlLAS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roster_person`
--

CREATE TABLE IF NOT EXISTS `roster_person` (
  `person_id` varchar(36) NOT NULL,
  `roster_id` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roster_person`
--

INSERT INTO `roster_person` (`person_id`, `roster_id`) VALUES
('3799b4a6-c637-4f47-9a88-219f09beddee', '72711c97-237c-49af-a0e0-452fb01295a7'),
('57322168-3e82-4bf4-9d64-c23a1e00bf51', '8c992261-d4cc-4867-aec2-38d000292a43');

-- --------------------------------------------------------

--
-- Table structure for table `sport`
--

CREATE TABLE IF NOT EXISTS `sport` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `department_id` varchar(36) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sport`
--

INSERT INTO `sport` (`id`, `name`, `department_id`, `version`) VALUES
('5648e73f-1f9f-4249-9dcc-a3ba40f7b2ae', 'Angleball', NULL, 2),
('574b4b92-f95f-4021-8b14-1f63e3f100cc', 'Ten-pin bowling', NULL, 2),
('e92b8eb8-8d2f-11e5-8994-feff819cdc9f', 'Football    ', NULL, 2),
('e92b920a-8d2f-11e5-8994-feff819cdc9f', 'Jazz-Dance', NULL, 2),
('e92b93b8-8d2f-11e5-8994-feff819cdc9f', 'Swimming', NULL, 2),
('e92b97be-8d2f-11e5-8994-feff819cdc9f', 'Water-Soccer', NULL, 2),
('e92b9cfa-8d2f-11e5-8994-feff819cdc9f', 'Skiing', NULL, 2),
('ea252d67-9e8e-444f-908b-3800eeb8e06b', 'Irish Road Bowling', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE IF NOT EXISTS `team` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sport_id` varchar(36) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `sport_id`, `version`) VALUES
('0a6c1426-a382-4a1c-a27a-cc40e75e03aa', 'Jazz-Dance Girls U18', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 3),
('10b36dc7-c8a1-44bb-96c3-ab90a2920386', 'Frauenfußball', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f', 3),
('300783e6-c4da-4a3b-b3c8-063f307b6e2d', 'Water-Soccer U14', 'e92b97be-8d2f-11e5-8994-feff819cdc9f', 4),
('575135ae-86d4-407c-ba24-067307c608ba', 'Niklas'' Buddies', 'e92b93b8-8d2f-11e5-8994-feff819cdc9f', 2),
('5e6cfb5d-696d-474a-9787-fe473cb11000', 'Michi', 'ea252d67-9e8e-444f-908b-3800eeb8e06b', 2),
('64738de2-c246-4862-aaaf-58f20dc15a0a', 'Bowling Men', 'ea252d67-9e8e-444f-908b-3800eeb8e06b', 2),
('77b6d3d6-5669-4790-b7c6-7c56e960b085', 'RandomMate', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0),
('7a277487-2bce-42f6-8ac2-86ee92f9c20c', 'D Rankler Bowler', 'ea252d67-9e8e-444f-908b-3800eeb8e06b', 0),
('7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1', 'Dreamteam', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0),
('9bb34421-ed31-4d4c-891f-113f0c728263', 'Irish Road Bowling - U18', 'ea252d67-9e8e-444f-908b-3800eeb8e06b', 1),
('9fd4ada9-29b5-40d5-a292-686096db5e51', 'Jazz-Dance Girls U14', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 2),
('9fd74103-ecf4-4924-b861-0f4efa441fee', 'Team Awesome', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0),
('a0a4170a-b066-458f-a803-dcf80e9eead8', 'Water-Soccer U30', 'e92b97be-8d2f-11e5-8994-feff819cdc9f', 6),
('a5c3194d-1318-4c80-84a0-05d89b58cb9c', 'Teenage Mutant Ninja Pongers', '5648e73f-1f9f-4249-9dcc-a3ba40f7b2ae', 1),
('a862648b-a772-4a8a-9c9e-af671eb018f6', 'Brangelina', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0),
('e92ba06a-8d2f-11e5-8994-feff819cdc9f', 'Football U18', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f', 1),
('e92ba376-8d2f-11e5-8994-feff819cdc9f', 'Jazz-Dance Girls U14', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 1),
('f6289630-e26e-4661-ae5c-c0d24c0368a5', 'Fußball U14', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f', 1);

-- --------------------------------------------------------

--
-- Table structure for table `team_person`
--

CREATE TABLE IF NOT EXISTS `team_person` (
  `person_id` varchar(36) NOT NULL,
  `team_id` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `team_person`
--

INSERT INTO `team_person` (`person_id`, `team_id`) VALUES
('0d26e707-6a20-47cf-bb1b-f65c5edfb0c1', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('231cd6ed-f033-499e-abb8-abaa60826d1f', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('3799b4a6-c637-4f47-9a88-219f09beddee', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('57322168-3e82-4bf4-9d64-c23a1e00bf51', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('71cfa130-ed9c-4b91-bacd-dfdfb58ed572', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('72ea88dd-2962-462d-bc55-9b14a80d4d52', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('93550bad-9d9b-4502-852f-972769e492f6', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('9d1275c5-b4b5-468a-bf21-63922139f334', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('cf0fc9f5-0e72-406e-b365-b69e52e335d8', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('e8f036f9-6f99-4a7f-8411-2c62063539f2', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('0d26e707-6a20-47cf-bb1b-f65c5edfb0c1', '10b36dc7-c8a1-44bb-96c3-ab90a2920386'),
('5ed81ec1-a9b5-4c1e-a6b7-0ae11395f4a4', '10b36dc7-c8a1-44bb-96c3-ab90a2920386'),
('6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', '10b36dc7-c8a1-44bb-96c3-ab90a2920386'),
('72ea88dd-2962-462d-bc55-9b14a80d4d52', '10b36dc7-c8a1-44bb-96c3-ab90a2920386'),
('3799b4a6-c637-4f47-9a88-219f09beddee', '300783e6-c4da-4a3b-b3c8-063f307b6e2d'),
('57322168-3e82-4bf4-9d64-c23a1e00bf51', '300783e6-c4da-4a3b-b3c8-063f307b6e2d'),
('604a80ca-4610-4155-88a2-ec7e4b40e9ca', '300783e6-c4da-4a3b-b3c8-063f307b6e2d'),
('68a4dbb2-d644-461f-b1e3-8021d0e44464', '300783e6-c4da-4a3b-b3c8-063f307b6e2d'),
('7f86baa0-a6c7-42bd-9870-3697ae2fa1f6', '300783e6-c4da-4a3b-b3c8-063f307b6e2d'),
('37ef7152-4187-45bb-a4a1-5126e3f4d1c7', '575135ae-86d4-407c-ba24-067307c608ba'),
('41f04f60-c399-42fb-9331-03aac7694fc2', '575135ae-86d4-407c-ba24-067307c608ba'),
('604a80ca-4610-4155-88a2-ec7e4b40e9ca', '575135ae-86d4-407c-ba24-067307c608ba'),
('68a4dbb2-d644-461f-b1e3-8021d0e44464', '575135ae-86d4-407c-ba24-067307c608ba'),
('6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', '575135ae-86d4-407c-ba24-067307c608ba'),
('71cfa130-ed9c-4b91-bacd-dfdfb58ed572', '575135ae-86d4-407c-ba24-067307c608ba'),
('72ea88dd-2962-462d-bc55-9b14a80d4d52', '575135ae-86d4-407c-ba24-067307c608ba'),
('7f86baa0-a6c7-42bd-9870-3697ae2fa1f6', '575135ae-86d4-407c-ba24-067307c608ba'),
('231cd6ed-f033-499e-abb8-abaa60826d1f', '5e6cfb5d-696d-474a-9787-fe473cb11000'),
('3799b4a6-c637-4f47-9a88-219f09beddee', '5e6cfb5d-696d-474a-9787-fe473cb11000'),
('37ef7152-4187-45bb-a4a1-5126e3f4d1c7', '5e6cfb5d-696d-474a-9787-fe473cb11000'),
('57322168-3e82-4bf4-9d64-c23a1e00bf51', '5e6cfb5d-696d-474a-9787-fe473cb11000'),
('604a80ca-4610-4155-88a2-ec7e4b40e9ca', '5e6cfb5d-696d-474a-9787-fe473cb11000'),
('93550bad-9d9b-4502-852f-972769e492f6', '5e6cfb5d-696d-474a-9787-fe473cb11000'),
('3e6dde97-ee20-4a0c-b12d-6e2aa150dbc3', '64738de2-c246-4862-aaaf-58f20dc15a0a'),
('41f04f60-c399-42fb-9331-03aac7694fc2', '64738de2-c246-4862-aaaf-58f20dc15a0a'),
('72ea88dd-2962-462d-bc55-9b14a80d4d52', '64738de2-c246-4862-aaaf-58f20dc15a0a'),
('cf0fc9f5-0e72-406e-b365-b69e52e335d8', '64738de2-c246-4862-aaaf-58f20dc15a0a'),
('0d26e707-6a20-47cf-bb1b-f65c5edfb0c1', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('231cd6ed-f033-499e-abb8-abaa60826d1f', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('3799b4a6-c637-4f47-9a88-219f09beddee', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('37ef7152-4187-45bb-a4a1-5126e3f4d1c7', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('3e6dde97-ee20-4a0c-b12d-6e2aa150dbc3', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('41f04f60-c399-42fb-9331-03aac7694fc2', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('0d26e707-6a20-47cf-bb1b-f65c5edfb0c1', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('3e6dde97-ee20-4a0c-b12d-6e2aa150dbc3', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('41f04f60-c399-42fb-9331-03aac7694fc2', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('5ed81ec1-a9b5-4c1e-a6b7-0ae11395f4a4', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('7f86baa0-a6c7-42bd-9870-3697ae2fa1f6', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('93550bad-9d9b-4502-852f-972769e492f6', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('e8f036f9-6f99-4a7f-8411-2c62063539f2', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('0d7eeba8-bcac-4af8-a2bf-a4f159e85cf5', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('3799b4a6-c637-4f47-9a88-219f09beddee', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('57322168-3e82-4bf4-9d64-c23a1e00bf51', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('5ed81ec1-a9b5-4c1e-a6b7-0ae11395f4a4', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('604a80ca-4610-4155-88a2-ec7e4b40e9ca', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('68a4dbb2-d644-461f-b1e3-8021d0e44464', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('71cfa130-ed9c-4b91-bacd-dfdfb58ed572', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('93550bad-9d9b-4502-852f-972769e492f6', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('cf0fc9f5-0e72-406e-b365-b69e52e335d8', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('7f86baa0-a6c7-42bd-9870-3697ae2fa1f6', 'a0a4170a-b066-458f-a803-dcf80e9eead8'),
('93550bad-9d9b-4502-852f-972769e492f6', 'a0a4170a-b066-458f-a803-dcf80e9eead8'),
('cf0fc9f5-0e72-406e-b365-b69e52e335d8', 'a0a4170a-b066-458f-a803-dcf80e9eead8'),
('68a4dbb2-d644-461f-b1e3-8021d0e44464', 'a5c3194d-1318-4c80-84a0-05d89b58cb9c'),
('6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', 'a5c3194d-1318-4c80-84a0-05d89b58cb9c'),
('71cfa130-ed9c-4b91-bacd-dfdfb58ed572', 'a5c3194d-1318-4c80-84a0-05d89b58cb9c'),
('89b57ed7-ec02-44f9-947c-75aceae661bb', 'e92ba06a-8d2f-11e5-8994-feff819cdc9f'),
('604a80ca-4610-4155-88a2-ec7e4b40e9ca', 'f6289630-e26e-4661-ae5c-c0d24c0368a5'),
('68a4dbb2-d644-461f-b1e3-8021d0e44464', 'f6289630-e26e-4661-ae5c-c0d24c0368a5'),
('6d117c8b-df92-48e6-bc8b-419e5b2c6d1a', 'f6289630-e26e-4661-ae5c-c0d24c0368a5'),
('71cfa130-ed9c-4b91-bacd-dfdfb58ed572', 'f6289630-e26e-4661-ae5c-c0d24c0368a5');

-- --------------------------------------------------------

--
-- Table structure for table `tournament`
--

CREATE TABLE IF NOT EXISTS `tournament` (
  `id` varchar(36) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sport_id` varchar(36) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  `location` varchar(255) DEFAULT NULL,
  `start` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tournament`
--

INSERT INTO `tournament` (`id`, `description`, `sport_id`, `version`, `location`, `start`) VALUES
('09d50e2e-0d36-4b71-9589-d317b690681b', 'same', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'some', '2015-12-14 00:00:00'),
('3252d203-65de-48b3-afe9-5d641afe7002', 'Dancing Stars', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'New York', '2015-12-18 00:00:00'),
('32e59a32-ba39-424d-85cf-b3627a3f57a6', 'Irish Bowling - Cup', 'ea252d67-9e8e-444f-908b-3800eeb8e06b', 0, 'Muntlix', '2015-12-11 00:00:00'),
('5d5c2c90-45a1-4e57-8d45-3cea71f7a134', 'Tanzturnier', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Alberschwende', '2015-12-01 00:00:00'),
('777c0313-60e3-4294-b442-41df357bbb8f', 'hallo', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 1, 'somesome', '2015-11-28 00:00:00'),
('7c9daf6c-0785-4cfd-b7a7-27ef4f79b3ad', 'Jazz-Dance Tournament', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Hohenems', '2015-12-02 00:00:00'),
('7cb84713-ae87-4fa1-aab5-129a332b16d4', 'Frauenfußball-Turnier 2015', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f', 0, 'Hard', '2015-12-04 00:00:00'),
('81750668-1318-40c7-8a86-fdc28d2adbb0', 'Unreal Brutal Tournament Shit', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Uganda', '2015-12-15 00:00:00'),
('91932896-bdf6-4982-866a-07cf91c2aaef', 'Football Tournament ', 'e92b8eb8-8d2f-11e5-8994-feff819cdc9f', 0, 'Dornbirn', '2015-12-07 00:00:00'),
('9234c857-f77b-4f56-8d48-1e007313b128', 'Tournament', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Local', '2015-12-03 00:00:00'),
('95ffa7a7-a0ae-4c00-babc-af8599520e9b', 'Dance with Stars', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Los Angeles', '2015-12-08 00:00:00'),
('d4f93fda-63d7-4fcf-b0a4-c8909f497a65', 'test', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'dornbirn', '2015-11-26 00:00:00'),
('d8aa91d1-da89-4e8f-b0ba-910d5dea3260', 'Grümpelturnier', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Alberschwende', '2015-11-26 00:00:00'),
('da5e56ed-f908-4f7c-b682-2fed72db4549', 'Dance Award', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Alberschwende', '2015-12-05 00:00:00'),
('e41cfa4b-3cf1-4ea0-bdb4-d77897fad070', 'Extreme Brutal', 'e92b920a-8d2f-11e5-8994-feff819cdc9f', 0, 'Uganda', '2015-12-23 00:00:00'),
('efaebdd1-8fae-4d6c-9c59-9a08807e0b71', 'NEED A BETTER NAME TOURNAMENT', 'ea252d67-9e8e-444f-908b-3800eeb8e06b', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tournament_team`
--

CREATE TABLE IF NOT EXISTS `tournament_team` (
  `tournament_id` varchar(36) NOT NULL,
  `team_id` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tournament_team`
--

INSERT INTO `tournament_team` (`tournament_id`, `team_id`) VALUES
('09d50e2e-0d36-4b71-9589-d317b690681b', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('3252d203-65de-48b3-afe9-5d641afe7002', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('5d5c2c90-45a1-4e57-8d45-3cea71f7a134', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('777c0313-60e3-4294-b442-41df357bbb8f', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('7c9daf6c-0785-4cfd-b7a7-27ef4f79b3ad', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('9234c857-f77b-4f56-8d48-1e007313b128', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('d4f93fda-63d7-4fcf-b0a4-c8909f497a65', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('d8aa91d1-da89-4e8f-b0ba-910d5dea3260', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('da5e56ed-f908-4f7c-b682-2fed72db4549', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('e41cfa4b-3cf1-4ea0-bdb4-d77897fad070', '0a6c1426-a382-4a1c-a27a-cc40e75e03aa'),
('7cb84713-ae87-4fa1-aab5-129a332b16d4', '10b36dc7-c8a1-44bb-96c3-ab90a2920386'),
('91932896-bdf6-4982-866a-07cf91c2aaef', '10b36dc7-c8a1-44bb-96c3-ab90a2920386'),
('32e59a32-ba39-424d-85cf-b3627a3f57a6', '5e6cfb5d-696d-474a-9787-fe473cb11000'),
('32e59a32-ba39-424d-85cf-b3627a3f57a6', '64738de2-c246-4862-aaaf-58f20dc15a0a'),
('e41cfa4b-3cf1-4ea0-bdb4-d77897fad070', '77b6d3d6-5669-4790-b7c6-7c56e960b085'),
('32e59a32-ba39-424d-85cf-b3627a3f57a6', '7a277487-2bce-42f6-8ac2-86ee92f9c20c'),
('5d5c2c90-45a1-4e57-8d45-3cea71f7a134', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('81750668-1318-40c7-8a86-fdc28d2adbb0', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('95ffa7a7-a0ae-4c00-babc-af8599520e9b', '7a9361e3-b3bc-4d10-89c4-dfa4b38b0fb1'),
('32e59a32-ba39-424d-85cf-b3627a3f57a6', '9bb34421-ed31-4d4c-891f-113f0c728263'),
('09d50e2e-0d36-4b71-9589-d317b690681b', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('5d5c2c90-45a1-4e57-8d45-3cea71f7a134', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('777c0313-60e3-4294-b442-41df357bbb8f', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('7c9daf6c-0785-4cfd-b7a7-27ef4f79b3ad', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('9234c857-f77b-4f56-8d48-1e007313b128', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('d4f93fda-63d7-4fcf-b0a4-c8909f497a65', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('d8aa91d1-da89-4e8f-b0ba-910d5dea3260', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('da5e56ed-f908-4f7c-b682-2fed72db4549', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('e41cfa4b-3cf1-4ea0-bdb4-d77897fad070', '9fd4ada9-29b5-40d5-a292-686096db5e51'),
('95ffa7a7-a0ae-4c00-babc-af8599520e9b', '9fd74103-ecf4-4924-b861-0f4efa441fee'),
('3252d203-65de-48b3-afe9-5d641afe7002', 'a862648b-a772-4a8a-9c9e-af671eb018f6');

-- --------------------------------------------------------

--
-- Table structure for table `userright`
--

CREATE TABLE IF NOT EXISTS `userright` (
  `id` varchar(36) NOT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userright`
--

INSERT INTO `userright` (`id`, `version`, `description`, `name`) VALUES
('0ced928c-9802-11e5-87f2-06261aa2f4c1', 0, NULL, 'PERSON_MODIFY'),
('19fde92e-9802-11e5-87f2-06261aa2f4c1', 0, NULL, 'TEAM_MODIFY'),
('2390a056-9802-11e5-87f2-06261aa2f4c1', 0, NULL, 'TOURNAMENT_MODIFY');

-- --------------------------------------------------------

--
-- Table structure for table `userrole`
--

CREATE TABLE IF NOT EXISTS `userrole` (
  `id` varchar(36) NOT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userrole`
--

INSERT INTO `userrole` (`id`, `version`, `description`, `name`) VALUES
('d0c3e9b8-9801-11e5-87f2-06261aa2f4c1', 0, NULL, 'Trainer'),
('e6c77ad6-9801-11e5-87f2-06261aa2f4c1', 0, NULL, 'Administrator'),
('f2f583a1-9801-11e5-87f2-06261aa2f4c1', 0, NULL, 'Member');

-- --------------------------------------------------------

--
-- Table structure for table `userrole_userright`
--

CREATE TABLE IF NOT EXISTS `userrole_userright` (
  `userrole_id` varchar(36) NOT NULL,
  `userright_id` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userrole_userright`
--

INSERT INTO `userrole_userright` (`userrole_id`, `userright_id`) VALUES
('d0c3e9b8-9801-11e5-87f2-06261aa2f4c1', '0ced928c-9802-11e5-87f2-06261aa2f4c1'),
('e6c77ad6-9801-11e5-87f2-06261aa2f4c1', '0ced928c-9802-11e5-87f2-06261aa2f4c1'),
('f2f583a1-9801-11e5-87f2-06261aa2f4c1', '0ced928c-9802-11e5-87f2-06261aa2f4c1'),
('d0c3e9b8-9801-11e5-87f2-06261aa2f4c1', '19fde92e-9802-11e5-87f2-06261aa2f4c1'),
('e6c77ad6-9801-11e5-87f2-06261aa2f4c1', '19fde92e-9802-11e5-87f2-06261aa2f4c1'),
('e6c77ad6-9801-11e5-87f2-06261aa2f4c1', '2390a056-9802-11e5-87f2-06261aa2f4c1');

-- --------------------------------------------------------

--
-- Table structure for table `user_userrole`
--

CREATE TABLE IF NOT EXISTS `user_userrole` (
  `username` varchar(255) NOT NULL,
  `userrole_id` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_userrole`
--

INSERT INTO `user_userrole` (`username`, `userrole_id`) VALUES
('cme8625', 'd0c3e9b8-9801-11e5-87f2-06261aa2f4c1'),
('mtr6934', 'e6c77ad6-9801-11e5-87f2-06261aa2f4c1'),
('psc6365', 'e6c77ad6-9801-11e5-87f2-06261aa2f4c1'),
('sha9939', 'e6c77ad6-9801-11e5-87f2-06261aa2f4c1'),
('tf-test', 'e6c77ad6-9801-11e5-87f2-06261aa2f4c1'),
('cme8625', 'f2f583a1-9801-11e5-87f2-06261aa2f4c1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `externalteam`
--
ALTER TABLE `externalteam`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `internalteam`
--
ALTER TABLE `internalteam`
  ADD PRIMARY KEY (`team_id`),
  ADD KEY `internalteam_person__fk` (`trainer_id`);

--
-- Indexes for table `match_`
--
ALTER TABLE `match_`
  ADD PRIMARY KEY (`id`),
  ADD KEY `match_tournament__fk` (`tournament_id`);

--
-- Indexes for table `match_team`
--
ALTER TABLE `match_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `match_team_team__fk` (`team_id`),
  ADD KEY `match_team_roster__fk` (`roster_id`),
  ADD KEY `match_team_match__fk` (`match_id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `person_username_uindex` (`username`);

--
-- Indexes for table `person_sport`
--
ALTER TABLE `person_sport`
  ADD PRIMARY KEY (`person_id`,`sport_id`),
  ADD KEY `person_sport_sport__fk` (`sport_id`);

--
-- Indexes for table `roster`
--
ALTER TABLE `roster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roster_person`
--
ALTER TABLE `roster_person`
  ADD PRIMARY KEY (`person_id`,`roster_id`),
  ADD KEY `roster_person_roster__fk` (`roster_id`);

--
-- Indexes for table `sport`
--
ALTER TABLE `sport`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sport_department__fk` (`department_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_sport__fk` (`sport_id`);

--
-- Indexes for table `team_person`
--
ALTER TABLE `team_person`
  ADD PRIMARY KEY (`person_id`,`team_id`),
  ADD KEY `team_person_team__fk` (`team_id`);

--
-- Indexes for table `tournament`
--
ALTER TABLE `tournament`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tournament_sport__fk` (`sport_id`);

--
-- Indexes for table `tournament_team`
--
ALTER TABLE `tournament_team`
  ADD PRIMARY KEY (`tournament_id`,`team_id`),
  ADD KEY `tournament_team_team__fk` (`team_id`);

--
-- Indexes for table `userright`
--
ALTER TABLE `userright`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userrole`
--
ALTER TABLE `userrole`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userrole_userright`
--
ALTER TABLE `userrole_userright`
  ADD PRIMARY KEY (`userrole_id`,`userright_id`),
  ADD KEY `userrole_userright_userright_id_fk` (`userright_id`);

--
-- Indexes for table `user_userrole`
--
ALTER TABLE `user_userrole`
  ADD PRIMARY KEY (`username`,`userrole_id`),
  ADD KEY `user_userrole_userrole__fk` (`userrole_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `internalteam`
--
ALTER TABLE `internalteam`
  ADD CONSTRAINT `internalteam_person__fk` FOREIGN KEY (`trainer_id`) REFERENCES `person` (`id`);

--
-- Constraints for table `match_`
--
ALTER TABLE `match_`
  ADD CONSTRAINT `match_tournament__fk` FOREIGN KEY (`tournament_id`) REFERENCES `tournament` (`id`);

--
-- Constraints for table `match_team`
--
ALTER TABLE `match_team`
  ADD CONSTRAINT `match_team_match__fk` FOREIGN KEY (`match_id`) REFERENCES `match_` (`id`),
  ADD CONSTRAINT `match_team_roster__fk` FOREIGN KEY (`roster_id`) REFERENCES `roster` (`id`),
  ADD CONSTRAINT `match_team_team__fk` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`);

--
-- Constraints for table `person_sport`
--
ALTER TABLE `person_sport`
  ADD CONSTRAINT `person_sport_person__fk` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`),
  ADD CONSTRAINT `person_sport_sport__fk` FOREIGN KEY (`sport_id`) REFERENCES `sport` (`id`);

--
-- Constraints for table `roster_person`
--
ALTER TABLE `roster_person`
  ADD CONSTRAINT `roster_person_person__fk` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`),
  ADD CONSTRAINT `roster_person_roster__fk` FOREIGN KEY (`roster_id`) REFERENCES `roster` (`id`);

--
-- Constraints for table `sport`
--
ALTER TABLE `sport`
  ADD CONSTRAINT `sport_department__fk` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`);

--
-- Constraints for table `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `team_sport__fk` FOREIGN KEY (`sport_id`) REFERENCES `sport` (`id`);

--
-- Constraints for table `team_person`
--
ALTER TABLE `team_person`
  ADD CONSTRAINT `team_person_person__fk` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`),
  ADD CONSTRAINT `team_person_team__fk` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`);

--
-- Constraints for table `tournament`
--
ALTER TABLE `tournament`
  ADD CONSTRAINT `tournament_sport__fk` FOREIGN KEY (`sport_id`) REFERENCES `sport` (`id`);

--
-- Constraints for table `tournament_team`
--
ALTER TABLE `tournament_team`
  ADD CONSTRAINT `tournament_team_team__fk` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`),
  ADD CONSTRAINT `tournament_team_tournament__fk` FOREIGN KEY (`tournament_id`) REFERENCES `tournament` (`id`);

--
-- Constraints for table `userrole_userright`
--
ALTER TABLE `userrole_userright`
  ADD CONSTRAINT `userrole_userright_userright_id_fk` FOREIGN KEY (`userright_id`) REFERENCES `userright` (`id`),
  ADD CONSTRAINT `userrole_userright_userrole_id_fk` FOREIGN KEY (`userrole_id`) REFERENCES `userrole` (`id`);

--
-- Constraints for table `user_userrole`
--
ALTER TABLE `user_userrole`
  ADD CONSTRAINT `user_userrole_person_username_fk` FOREIGN KEY (`username`) REFERENCES `person` (`username`),
  ADD CONSTRAINT `user_userrole_userrole__fk` FOREIGN KEY (`userrole_id`) REFERENCES `userrole` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
